package com.cg.lpg.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.lpg.dto.LPGStockDto;
import com.cg.lpg.exception.LPGException;
import com.cg.lpg.service.ILPGService;
import com.cg.lpg.service.LPGServiceImpl;

/**
 * Servlet implementation class LPGController
 */
@WebServlet("/LPGController")
public class LPGController extends HttpServlet {
	private static final long serialVersionUID = 1L;
   ILPGService lpgService = new LPGServiceImpl();
    /**
     * Default constructor. 
     */
    public LPGController() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
HttpSession session = request.getSession(true);
String action = request.getParameter("action");
System.out.println("action is ...... "+action);
String location = request.getParameter("loaction");
System.out.println("Location is ...... "+location);

if(location!=null)
{
	session.setAttribute("location", location);
	try{
		ArrayList<LPGStockDto> stocklist = lpgService.getStockDetails(location);
		if(stocklist.isEmpty())
			throw new LPGException("Sorry! No records founr...");
		session.setAttribute("list", stocklist);
	}catch(LPGException e){
		throw new ServletException(e);
	}
	RequestDispatcher dispatcher = request.getRequestDispatcher("getStock.jsp");
	dispatcher.forward(request, response);
}
if("updateForm".equals(action)){
	String quantity = request.getParameter("qty");
	String provider = request.getParameter("provider");
session.setAttribute("availableQty", quantity);
session.setAttribute("provider", provider);
RequestDispatcher dispatcher1 = request.getRequestDispatcher("updateStock.jsp");
dispatcher1.forward(request, response);

}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		String action = request.getParameter("action");
		if("updtae".equals(action)){
			int requiredQuantity = Integer.parseInt(request.getParameter("requiredQty"));
			String gasProvider = request.getParameter("provider");
			try{
				boolean flag=lpgService.updateStockDetails(requiredQuantity, gasProvider);
				if(flag){
					RequestDispatcher dispatcher = request.getRequestDispatcher("success.jsp");
					dispatcher.forward(request, response);
				}
			}catch(LPGException e){
				throw new ServletException(e);
			}
		}
	}

}
