package com.cg.lpg.dto;

import java.time.LocalDate;

public class LPGStockDto {
private int avQty;
private LocalDate receivedDate;
private String updateBy;
private String location;
public LPGStockDto() {
	super();
}
public int getAvQty() {
	return avQty;
}
public void setAvQty(int avQty) {
	this.avQty = avQty;
}
public LocalDate getReceivedDate() {
	return receivedDate;
}
public void setReceivedDate(LocalDate receivedDate) {
	this.receivedDate = receivedDate;
}
public String getUpdateBy() {
	return updateBy;
}
public void setUpdateBy(String updateBy) {
	this.updateBy = updateBy;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}



}
