package com.cg.lpg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.cg.lpg.dto.LPGStockDto;
import com.cg.lpg.exception.LPGException;
import com.cg.lpg.util.DBUtil;

public class LPGDaoImpl implements ILPGDao{
static Connection connection = null;
static {
	try {
		connection = DBUtil.obtainConnection();
	} catch (LPGException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
	@Override
	public ArrayList<LPGStockDto> getStockDetails(String location)
			throws LPGException {
		PreparedStatement statement=null;
		ResultSet resultSet=null;
		String query="select * from lpgstock where loaction=(?)";
		System.out.println("Loaction is: "+location);
		ArrayList<LPGStockDto> stockList= new ArrayList<LPGStockDto>();
		LPGStockDto dto = null;
		try{
			statement=connection.prepareStatement(query);
			statement.setString(1,location);
			resultSet = statement.executeQuery();
			while(resultSet.next())
			{
				System.out.println("ResultSet coming");
				dto = new LPGStockDto();
				dto.setAvQty(resultSet.getInt(1));
				dto.setReceivedDate(resultSet.getDate(2).toLocalDate());
				dto.setUpdateBy(resultSet.getString(3));
				dto.setLocation(resultSet.getString(4));
				stockList.add(dto);
			}
		}catch(Exception e){
			throw new LPGException("Something went wrong while fetching");
		}
		return stockList;
	}

	@Override
	public boolean updateStockDetails(int quantity, String provider)
			throws LPGException {
	PreparedStatement statement = null;
	int result = 0;
	String query = "Update lpgstock set avqty=avqty-? where updatedby=?";
	boolean flag = false;
	try{
		statement=connection.prepareStatement(query);
		statement.setInt(1, quantity);
		statement.setString(2, provider);
		result = statement.executeUpdate();
		
		if(result > 0)
		{
			flag=true;
		}else
			throw new LPGException("Something went wrong while processing");
		
	}catch(Exception e)
	{
		throw new LPGException("Unable to update stock details at this ");
	}
	return flag;
	}

}
